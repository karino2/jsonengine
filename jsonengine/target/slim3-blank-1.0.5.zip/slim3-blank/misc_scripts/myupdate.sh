# /Users/karino/Program/eclipse/plugins/com.google.appengine.eclipse.sdkbundle_1.7.2/appengine-java-sdk-1.7.2/bin/appcfg.sh update ../war
/Users/karino/Documents/work/appengine-java-sdk-1.9.2/bin/appcfg.sh update ../war
